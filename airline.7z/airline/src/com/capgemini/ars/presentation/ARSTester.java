package com.capgemini.ars.presentation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.ars.bean.AirportBean;
import com.capgemini.ars.bean.BookingBean;
import com.capgemini.ars.bean.FlightBean;
import com.capgemini.ars.bean.UserBean;
import com.capgemini.ars.exception.ARSException;
import com.capgemini.ars.service.AirportServiceImpl;
import com.capgemini.ars.service.BookingServiceImpl;
import com.capgemini.ars.service.FlightserviceImpl;
import com.capgemini.ars.service.IBookingservice;
import com.capgemini.ars.service.IFlightservice;
import com.capgemini.ars.service.IUserService;
import com.capgemini.ars.service.IairportService;
import com.capgemini.ars.service.UserServiceImpl;

public class ARSTester {

	public static IBookingservice bookingService = new BookingServiceImpl();
	public static IFlightservice flightService= new FlightserviceImpl();
	public static 	IUserService userService = new UserServiceImpl();
	public static IairportService airportService= new AirportServiceImpl();
	public static  Scanner scanner= new Scanner(System.in);

	public static void main(String[] args) throws ARSException, ParseException {
		while(true){
			System.out.println("*************************************");
			System.out.println();
			System.out.println("AIRLINE RESERVATION SYSTEM");
			System.out.println();
			System.out.println("*************************************");

			System.out.println("1.Register ");
			System.out.println("2.Login ");
			System.out.println("3.Exit ");
			System.out.println();
			System.out.println("Enter your choice");
			try{
				int n= scanner.nextInt();

				switch(n){
				case 1:
					int flag=0;
					while(flag==0){

						System.out.println("Enter your username(Username should not contain spaces...use '_' instead)");
						String uname= scanner.next();

						System.out.println("Create your password");
						String pwd= scanner.next();
						System.out.println("Confirm your password");
						String cpwd= scanner.next();


						if(pwd.equals(cpwd)){
							flag=1;
							System.out.println("Enter your mobile no:");
							Long mobileNo=scanner.nextLong();

							UserBean user = new UserBean(uname,pwd,mobileNo,"USER");
							userService.addUserDetails(user);
							System.out.println("Registered Successfully.....");
							System.out.println("Please Login now...");

						}else{

							System.err.print("your passwords don't match");


						}
					}

					break;
				case 2: System.out.println("Please Login Here....");
				System.out.println("Enter your username:");
				String uname =  scanner.next();
				System.out.println("Enter password:");
				String password = scanner.next();
				if(userService.getUserRole(uname, password).equalsIgnoreCase("USER")){
					UserBean user=new UserBean(uname);
					System.out.println("Welcome dear "+user.getUserName()+" to Airline Reservation System");
					System.out.println("1.Book Ticket");
					System.out.println("2.View your booking history");
					System.out.println("3.Update your email.");
					System.out.println("4.Cancel Booking");
					System.out.println("Enter your choice:");
					String classType="";
					Double totalfare=0.0;
					try{
						Integer choice=scanner.nextInt();
						switch(choice){
						case 1:
							List<AirportBean> airportList = airportService.getAirportNames();
							Iterator<AirportBean> iterator= airportList.iterator();
							while(iterator.hasNext()){
								System.out.println(iterator.next());
							} 
							System.out.println("Enter departure_city");
							String srcCity=scanner.next();
							System.out.println("Enter destination:");
							String destCity=scanner.next();
							System.out.println("Enter date of journey");
							String doj=scanner.next();
							SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yyyy");
							java.util.Date date = sdf1.parse(doj);
							java.sql.Date sqlStartDate = new java.sql.Date(date.getTime()); 
							List<FlightBean> flightList=flightService.getFlights(srcCity, destCity, sqlStartDate);
							Iterator<FlightBean> flightiterator= flightList.iterator();
							while(flightiterator.hasNext()){
								System.out.println(flightiterator.next());
							} 
							System.out.println("Enter existing flightno from the above list ");
							String flightno = scanner.next();
							if(flightService.isValidFlightNo(srcCity, destCity, sqlStartDate, flightno)){
								System.out.println("Enter your mail Id");
								String custEmail = scanner.next();
								System.out.println("Enter number of seats:");
								Integer noOfPassengers=scanner.nextInt();
								for(int i=1;i<=noOfPassengers;i++){
								System.out.println("Select the type of seats:1.FirstClass 2.BussinessSeats");
								System.out.println("Select the above type no");
								try{
									Integer seatType = scanner.nextInt();
									if(seatType==1){
										classType="FIRSTCLASS";
										totalfare = flightService.firstClassFare(flightno)*(noOfPassengers);
									}
									else if(seatType==2){
										classType="BUSSCLASS";
										totalfare = flightService.bussClassFare(flightno)*(noOfPassengers);
									}else{
										System.out.println("Please enter valid class type..");
									}
								}catch(InputMismatchException e){
									
									}
									System.out.println("Enter your credit card number:");
									String creditCardInfo=scanner.next();
									BookingBean bean =bookingService.addBookingDetails(custEmail, noOfPassengers, classType, creditCardInfo, srcCity, destCity, totalfare);
									System.out.println("Your booking Id:"+bean.getBookingId());
									System.out.println("Your Seat Number"+bean.getSeatNo());
								}
									
								
								
							
							}
							
							
							
							
							break;




						}

					}catch(InputMismatchException e){
						e.printStackTrace();
					}
				}	
				}





			}catch(InputMismatchException e){
				e.printStackTrace();

			}







		}


	}

}
