package com.capgemini.ars.service;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.ars.bean.BookingBean;
import com.capgemini.ars.dao.BookingDaoImpl;
import com.capgemini.ars.dao.IBookingDao;
import com.capgemini.ars.exception.ARSException;

public class BookingServiceImpl implements IBookingservice{
	IBookingDao bookingDAO=new BookingDaoImpl();

	@Override
	public BookingBean addBookingDetails(String custEmail,
			Integer noOfPassengers, String classType, String creditCardInfo,
			String srcCity, String destCity, Double totalfare)
			throws ARSException {
		BookingBean booking = new BookingBean();
		booking=bookingDAO.addBookingDetails(custEmail, noOfPassengers, classType, creditCardInfo, srcCity, destCity, totalfare);
		return booking;
	}

	@Override
	public String deleteBookingDetails(Integer bookingId) throws ARSException {
		String message=bookingDAO.deleteBookingDetails(bookingId);
		return message;
	}

	@Override
	public List<BookingBean> retrieveAllBookingDetails(BookingBean bookingBean)
			throws ARSException {
		List<BookingBean> bookingList = new ArrayList<>();
		bookingList = bookingDAO.retrieveAllBookingDetails(bookingBean);
		return bookingList;
	}

	@Override
	public List<BookingBean> getBookingDetails(String custEmail)
			throws ARSException {
		List<BookingBean> bookingList = new ArrayList<>();
		bookingList = bookingDAO.getBookingDetails(custEmail);
		return bookingList;
	}

	@Override
	public Integer updateEmail(String Email, Integer bookingId)
			throws ARSException {
		Integer n = bookingDAO.updateEmail(Email, bookingId);
		return n;
	}

	

}
