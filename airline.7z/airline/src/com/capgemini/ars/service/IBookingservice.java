package com.capgemini.ars.service;


import java.util.List;

import com.capgemini.ars.bean.BookingBean;

import com.capgemini.ars.exception.ARSException;

public interface IBookingservice {
	public BookingBean  addBookingDetails(String custEmail,Integer noOfPassengers,String classType,String creditCardInfo,String srcCity,String destCity,Double totalfare) throws ARSException;
	public String deleteBookingDetails(Integer bookingId) throws ARSException;
public List<BookingBean> retrieveAllBookingDetails(BookingBean bookingBean) throws ARSException;
public List<BookingBean> getBookingDetails(String custEmail) throws ARSException;
public Integer updateEmail(String Email,Integer bookingId) throws ARSException;
}
