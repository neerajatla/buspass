package com.capgemini.ars.dao;

import java.util.List;

import com.capgemini.ars.bean.AirportBean;
import com.capgemini.ars.exception.ARSException;

public interface IAirportDao {
	
	public abstract List<AirportBean> getAirportNames() throws ARSException; 

}
