package com.capgemini.ars.dao;

import java.sql.Date;
import java.util.List;

import com.capgemini.ars.bean.FlightBean;
import com.capgemini.ars.exception.ARSException;

public interface IFlightDao {
	public abstract void addFlight(FlightBean flight)throws ARSException;
	public abstract void deleteFlight(String flightNo) throws ARSException;
	public abstract FlightBean updateFlight(FlightBean flight)throws ARSException;
	public abstract List<FlightBean> getAllFlightDetails()throws ARSException;
	public abstract List<FlightBean> getFlights(String dep_city,String arr_city,Date dep_date)throws ARSException;
	public abstract FlightBean getFlightDetails(String flightno) throws ARSException;
	public abstract Integer getFirstSeatOccupancy(String flightno) throws ARSException;
	public abstract Integer getBussSeatOccupancy(String flightno) throws ARSException;
	public abstract boolean isValidFlightNo(String dep_city,String arr_city,Date dep_date,String flightno)throws ARSException;
	public abstract Double firstClassFare(String flightno)throws ARSException;
	public abstract Double bussClassFare(String flightno)throws ARSException;


}
