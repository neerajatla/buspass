package com.capgemini.ars.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.ars.bean.BookingBean;
import com.capgemini.ars.exception.ARSException;
import com.capgemini.ars.utility.DBConnection;



public class BookingDaoImpl implements IBookingDao{



	@Override
	public BookingBean addBookingDetails(String custEmail,Integer noOfPassengers,String classType,String creditCardInfo,String srcCity,String destCity,Double totalfare) throws ARSException {

		int bookingCount=0;
		try(
				Connection connection=DBConnection.getConnection();
				PreparedStatement preparedStatement= connection.prepareStatement
						("insert into bookinginfo(Booking_id, cust_email, no_of_passengers, class_type,total_fare, CreditCard_info, src_city, dest_city) values(booking_id_sequence.NEXTVAL,?,?,?,?,?,?,?)");
				PreparedStatement pstmt=connection.prepareStatement
						("insert into bookinginfo(Booking_id, cust_email, no_of_passengers, class_type,total_fare, seat_number,CreditCard_info, src_city, dest_city)"
								+ " values(booking_id_sequence.NEXTVAL,?,?,?,?,?,?,?,?)");
				Statement statement = connection.createStatement();
				PreparedStatement pstatement = connection.prepareStatement("select firstclass_seat_number_seq.NEXTVAL from dual");
				PreparedStatement pstatement1 = connection.prepareStatement("select busseats_seat_number_seq.NEXTVAL from dual");
				
				//PreparedStatement ps=connection.prepareStatement("select firstclass_seat_number_seq.CURRVAL from dual");
				//PreparedStatement ps1=connection.prepareStatement("select busseats_seat_number_seq.CURRVAL from dual");
				) {
			/*preparedStatement.setString(1, custEmail);
			preparedStatement.setInt(2, noOfPassengers);
			preparedStatement.setString(3, classType);
			preparedStatement.setDouble(4, totalfare);
			preparedStatement.setString(5, creditCardInfo);
			preparedStatement.setString(6, srcCity);
			preparedStatement.setString(7, destCity);
			
			ResultSet resultSet=preparedStatement.executeQuery();
			
			
			
			if(resultSet.next()) {*/
				bookingCount++;
				BookingBean booking=new BookingBean();
				if(classType.equalsIgnoreCase("FIRSTCLASS")){
					ResultSet rs=pstatement.executeQuery();
					if(rs.next()){
					Integer firstClassSeatNo=rs.getInt(1);
					pstmt.setString(1, custEmail);
					pstmt.setInt(2, noOfPassengers);
					pstmt.setString(3, classType);
					pstmt.setDouble(4, totalfare);
					pstmt.setInt(5, firstClassSeatNo);
					pstmt.setString(6, creditCardInfo);
					pstmt.setString(7, srcCity);
					pstmt.setString(8, destCity);
					ResultSet resultSet=preparedStatement.executeQuery();
					//boolean rs1=statement.execute("select firstclass_seat_number_seq.NEXTVAL from dual");
					
					
					System.out.println(firstClassSeatNo);
					populateBooking(booking,resultSet);
					}
				}else if(classType.equalsIgnoreCase("BUSSCLASS")){
					ResultSet rs1=pstatement1.executeQuery();
					if(rs1.next()){
					Integer bussClassSeatno=rs1.getInt(1);
					pstmt.setString(1, custEmail);
					pstmt.setInt(2, noOfPassengers);
					pstmt.setString(3, classType);
					pstmt.setDouble(4, totalfare);
					pstmt.setInt(5, bussClassSeatno);
					pstmt.setString(6, creditCardInfo);
					pstmt.setString(7, srcCity);
					pstmt.setString(8, destCity);
					ResultSet resultSet=preparedStatement.executeQuery();
					
				
					
					populateBooking(booking,resultSet);
					}
				}
				
				System.out.println(booking);
				return booking;
			}
			
			if(bookingCount!=0) {
				
			}else {
				return null;
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	private void populateBooking(BookingBean booking, ResultSet resultSet) throws SQLException {
		
		booking.setBookingId(resultSet.getInt("booking_id"));
		booking.setCustEmail(resultSet.getString("cust_email"));
		booking.setNoOfPassengers(resultSet.getInt("no_of_passengers"));
		booking.setClassType(resultSet.getString("class_type"));
		booking.setTotalFare(resultSet.getDouble("total_fare"));
		booking.setSeatNo(resultSet.getInt("seat_number"));
		booking.setCreditCardInfo(resultSet.getString("creditcard_info"));
		booking.setSrcCity(resultSet.getString("src_city"));
		booking.setDestCity(resultSet.getString("dest_city"));
		
		
	}

	@Override
	public String deleteBookingDetails(Integer bookingId)throws ARSException {

		try(   
			Connection connection=DBConnection.getConnection();
			PreparedStatement ps2=connection.prepareStatement("delete from bookinginfo where booking_id= ?");
			Statement statement = connection.createStatement();

	){
			ps2.setInt(1, bookingId);
			int n=ps2.executeUpdate();
			if(n>0) {
				//daoLogger.info("1 row deleted from mobiles table");
				return "SUCCESS";
			}else {
				//daoLogger.info("Delete failed.Invalid mobile id");
				return "FAIL";
			}
		}catch(SQLException e){
		e.printStackTrace();
		throw new ARSException("Technical Error. Refer to log");

	}
		
		
}

	@Override
	public List<BookingBean> retrieveAllBookingDetails(BookingBean bookingBean) throws ARSException {
		String sql="select * from bookinginfo";
		int bookingcount=0;
		try(   
				Connection connection=DBConnection.getConnection();
				Statement statement = connection.createStatement();
){
			ResultSet resultSet=statement.executeQuery(sql);
			
			List<BookingBean> bookingList=new ArrayList<>();
			while(resultSet.next()){
				bookingcount++;
				BookingBean booking=new BookingBean();
				try{
				populateBookings(booking,resultSet);
				}catch(SQLException e){
					
				}
				bookingList.add(booking);
			}
			if(bookingcount!=0){
				return bookingList;
			}
			else{
				return null;
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
		
		
		return null;
	}

	private void populateBookings(BookingBean booking, ResultSet resultSet) throws SQLException{
		try {
			booking.setBookingId(resultSet.getInt("booking_id"));
			booking.setCustEmail(resultSet.getString("cust_email"));
			booking.setNoOfPassengers(resultSet.getInt("no_of_passengers"));
			booking.setClassType(resultSet.getString("class_type"));
			booking.setSeatNo(resultSet.getInt("seat_number"));
			booking.setTotalFare(resultSet.getDouble("total_fare"));
			booking.setCreditCardInfo(resultSet.getString("creditcard_info"));
			booking.setSrcCity(resultSet.getString("src_city"));
			booking.setDestCity(resultSet.getString("dest_city"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public List<BookingBean> getBookingDetails(String custEmail) throws ARSException {
	     String sql="select * from bookinginfo where cust_email=?";
	     int bookingcount=0;
	     try(
	    	 Connection connection=DBConnection.getConnection();
					PreparedStatement statement = connection.prepareStatement(sql);
	    		
	    		 ){
	    	 statement.setString(1, custEmail);
	    	 ResultSet resultSet=statement.executeQuery();
				
				List<BookingBean> bookingList=new ArrayList<>();
				while(resultSet.next()){
					bookingcount++;
					BookingBean booking=new BookingBean();
					populateBookings(booking,resultSet);
					bookingList.add(booking);
				}
				if(bookingcount!=0){
					return bookingList;
				}
				else{
					return null;
				}
	    	 
	   
	     }catch(SQLException e){
	    	 e.printStackTrace();
	     }
		
		return null;
	}

	@Override
	public Integer updateEmail(String Email,Integer bookingId) throws ARSException {
      String sql="update bookinginfo set cust_email=? where booking_id=?";
		try(
    		  Connection connection=DBConnection.getConnection();
    		  PreparedStatement statement=connection.prepareStatement(sql)){
    	  statement.setString(1, Email);
    	  statement.setInt(2, bookingId);
    	
    	int n=statement.executeUpdate();
		return n;
    	  
      }catch(SQLException e){
    	  e.printStackTrace();
      }
		return null;
		
	}
	
}

