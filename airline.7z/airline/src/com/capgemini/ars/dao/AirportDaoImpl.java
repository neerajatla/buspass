package com.capgemini.ars.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.ars.bean.AirportBean;
import com.capgemini.ars.bean.FlightBean;
import com.capgemini.ars.exception.ARSException;
import com.capgemini.ars.utility.DBConnection;

public class AirportDaoImpl implements IAirportDao{

	@Override
	public List<AirportBean> getAirportNames() throws ARSException {
		int airPortCount=0;
		try(
				Connection connection = DBConnection.getConnection();
				Statement statement = connection.createStatement();
				
				){
			ResultSet resultSet = statement.executeQuery("select * from airport");
			List<AirportBean> airportList = new ArrayList<>();
			while(resultSet.next()){
				airPortCount++;
			AirportBean airport=new AirportBean();

				populateAirport(airport,resultSet);
				airportList.add(airport);
			}
			if(airPortCount!=0){
				return airportList;
			}else{
				return null;
			}
			
			
			
		}catch(SQLException e){
			e.printStackTrace();
		}
		return null;
	}

	private void populateAirport(AirportBean airport, ResultSet resultSet) throws SQLException {
		airport.setAirportName(resultSet.getString(1));
		airport.setAbbrevation(resultSet.getString(2));
		airport.setLocation(resultSet.getString(3));
		
	}

}
