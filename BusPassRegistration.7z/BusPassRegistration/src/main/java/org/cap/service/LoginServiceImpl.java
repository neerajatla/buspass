package org.cap.service;

import org.cap.bus.LoginBean;
import org.cap.dao.ILoginDao;
import org.cap.dao.LoginDaoImpl;

public class LoginServiceImpl implements ILoginService{
	
	ILoginDao logindao=new LoginDaoImpl();

	@Override
	public boolean isValidLogin(LoginBean loginbean) {

		System.out.println("Service");
		if(logindao.isValidLogin(loginbean)) {
			return true;
		}
		return false;
	}
	

}
