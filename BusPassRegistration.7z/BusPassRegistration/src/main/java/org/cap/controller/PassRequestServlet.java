package org.cap.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cap.bus.LoginBean;
import org.cap.service.ILoginService;
import org.cap.service.LoginServiceImpl;


@WebServlet("/PassRequestServlet")
public class PassRequestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		LoginBean loginbean=new LoginBean(username,password);
		
		ILoginService loginservice=new LoginServiceImpl();
		
		System.out.println("in servlet");
		response.setContentType("text/html");
		
		if(loginservice.isValidLogin(loginbean)) {
			response.sendRedirect("pages/mainPage.html");
		}else {
			PrintWriter pWriter=response.getWriter();
			request.getRequestDispatcher("index.html").include(request, response);
			pWriter.println("INVALID");
		}
		
	}

}
