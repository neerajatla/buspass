package org.cap.dao;

import org.cap.bus.LoginBean;

public interface ILoginDao {
	

	public boolean isValidLogin(LoginBean loginbean);

}
